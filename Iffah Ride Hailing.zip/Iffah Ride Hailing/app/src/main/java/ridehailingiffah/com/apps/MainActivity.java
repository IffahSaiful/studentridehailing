package ridehailingiffah.com.apps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {

    FirebaseAuth auth;
    EditText e1, e2;
    FirebaseUser user;

    //DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        e1 = (EditText)findViewById(R.id.editTextTextEmailAddress);
        e2 = (EditText)findViewById(R.id.editTextTextPassword);

        auth = FirebaseAuth.getInstance();

       // databaseReference = FirebaseDatabase.getInstance().
             //   getReferenceFromUrl("https://iffahride-hailing-default-rtdb.firebaseio.com/").child("Student").child(user.getUid());

        if(auth == null)
        {
            setContentView(R.layout.activity_main);
        }
        else
        {
           Intent myIntent  = new Intent (MainActivity.this,MyNavigationActivity.class);
           startActivity(myIntent);
           finish();
        }




        ImageView myimageView = (ImageView) findViewById(R.id.imageView);
        myimageView.setImageResource(R.drawable.uthm_community);
    }

    public void goToRegister(View v)
    {
        Intent myIntent = new Intent(MainActivity.this,SignupActivity.class);
        startActivity(myIntent);
    }

    public void login(View v)
    {
        auth.signInWithEmailAndPassword(e1.getText().toString(),e2.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(getApplicationContext(), "Logged in successfully", Toast.LENGTH_LONG).show();

                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Invalid credentials or you are not authorized to access this system. Please try again.", Toast.LENGTH_LONG).show();
                        }


                    }
                });

    }
}