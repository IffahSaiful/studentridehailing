package ridehailingiffah.com.apps;

public class CreateUser
{

    public CreateUser()
    {}

    public String name;

    public CreateUser(String name, String email, String password, String code, String isSharing, String lat, String log, String imageUrl) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.code = code;
        this.isSharing = isSharing;
        this.lat = lat;
        this.log = log;
        this.imageUrl = imageUrl;
    }

    public String email;
    public String password;
    public String code;
    public String isSharing;
    public String lat;
    public String log;
    public String imageUrl;

}
